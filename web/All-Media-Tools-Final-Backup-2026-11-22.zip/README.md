# All Media Tools

Website and FastAPI backend. Deploy the root Dockerfile on Render.

Website: /tools/
Health: /api/health

Adsterra is disabled until approved publisher code is configured.


## Search metadata

The homepage and six tool pages are generated for both Render (`web/`) and the static Sites package (`dist/`). Run `node scripts/build-seo.mjs` after editing the homepage template, shared scripts, or tool page copy.

Once a public HTTPS homepage URL is chosen, pass it to the generator to write canonical URLs, absolute sitemap entries, and the sitemap directive in robots.txt. For a Render homepage under `/tools/`, include that path and the trailing slash in the URL. For a domain-root homepage, the generator also includes Google site-name markup on the homepage.

```sh
node scripts/build-seo.mjs https://example.com/tools/
```

Publish using the same homepage URL, verify `/robots.txt` at the site origin, and submit the sitemap to Google Search Console. A static-only deployment requires a separate HTTPS API for server-powered tools. For the bundled application and API, use the Render Docker service.
