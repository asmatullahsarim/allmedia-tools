const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "../ads.js"), "utf8");

function render({ width, kind = "leaderboard", enabled = true, desktopOnly = false, desktop = false }) {
  const slot = {
    hidden: true,
    children: [],
    dataset: { displayAd: kind },
    classList: { contains: () => desktopOnly },
    replaceChildren(...children) { this.children = children; },
  };
  const document = {
    querySelectorAll: () => [slot],
    createElement: () => ({ setAttribute(key, value) { this[key] = value; } }),
  };
  class ResizeObserver {
    constructor(callback) { this.callback = callback; }
    observe() { this.callback([{ contentRect: { width } }]); }
  }
  vm.runInNewContext(source, { window: { ALLMEDIA_ADS: { enabled } }, document, ResizeObserver, matchMedia: () => ({ matches: desktop }) });
  return slot;
}

for (const [available, expected] of [[300, undefined], [320, 320], [500, 468], [900, 728]]) {
  assert.equal(render({ width: available }).children[1]?.width, expected);
}
assert.equal(render({ width: 320, kind: "rectangle" }).children[1].height, 250);
assert.equal(render({ width: 640, desktopOnly: true }).children.length, 0);
assert.equal(render({ width: 800, desktopOnly: true, desktop: true }).children[1].width, 728);
assert.equal(render({ width: 900, enabled: false }).hidden, true);
assert.doesNotMatch(render({ width: 320 }).children[1].sandbox, /allow-same-origin/);
