# Oracle Cloud deployment

Use an Always Free eligible Linux VM in the tenancy home region. Verify the selected shape, boot volume, and estimated cost in the Oracle console. The app image must build on the selected architecture before the live site is connected.

Install Docker with Compose, copy the project to the VM, and point the API hostname (for example, api.allmediatool.online) to the VM's public IP. In the Oracle network security rules and VM firewall, allow TCP 80 and 443. Limit SSH access to approved addresses. The Python service stays on Compose's internal network.

From the project root:

    API_HOSTNAME=api.allmediatool.online docker compose -f deploy/oci/compose.yaml up -d --build

Caddy obtains HTTPS after DNS and inbound ports are ready. Check the HTTPS /api/health response and test video and image extraction against known public content. Check that returned download links use the API HTTPS hostname. Then set backendUrl in the Hostinger site's public config.js to the verified HTTPS origin. Repeat the download tests through the live website. Leave the existing website's root DNS unchanged.
